package com.saapseedhi

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import fi.iki.elonen.NanoHTTPD
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.concurrent.ConcurrentLinkedQueue

class Srv(private val act: Activity) : NanoHTTPD(8080) {
    @Volatile var state = "{}"
    val q = ConcurrentLinkedQueue<String>()
    override fun serve(s: IHTTPSession): Response = when (s.uri) {
        "/state" -> newFixedLengthResponse(Response.Status.OK, "application/json", state)
        "/cmd" -> {
            val c = (s.parameters["c"]?.firstOrNull() ?: "").filter { it.isLetter() }
            val p = s.parameters["p"]?.firstOrNull()?.toIntOrNull() ?: 0
            q.add("{\"c\":\"$c\",\"p\":$p}")
            newFixedLengthResponse("ok")
        }
        else -> newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8",
            act.assets.open("controller.html").bufferedReader().readText())
    }
}

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var srv: Srv

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        srv = Srv(this); srv.start()
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.setBackgroundColor(0)
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/game.html")
        web.requestFocus()
    }

    override fun onWindowFocusChanged(f: Boolean) {
        super.onWindowFocusChanged(f)
        if (f) web.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
    }

    override fun onBackPressed() { web.evaluateJavascript("onBack()", null) }
    override fun onDestroy() { srv.stop(); super.onDestroy() }

    inner class Bridge {
        @JavascriptInterface fun setState(s: String) { srv.state = s }
        @JavascriptInterface fun poll(): String {
            val l = ArrayList<String>()
            while (true) { l.add(srv.q.poll() ?: break) }
            return "[" + l.joinToString(",") + "]"
        }
        @JavascriptInterface fun ip(): String = try {
            NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
                .firstOrNull { !it.isLoopbackAddress && it is Inet4Address }?.hostAddress ?: "?"
        } catch (e: Exception) { "?" }
        @JavascriptInterface fun exit() { runOnUiThread { finish() } }
    }
}
