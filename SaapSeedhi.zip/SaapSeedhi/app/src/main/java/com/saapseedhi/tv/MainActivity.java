package com.saapseedhi.tv;

import android.app.Activity;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.util.Enumeration;

public class MainActivity extends Activity {
    WebView wv;
    volatile String state = "{}";
    ServerSocket server;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        wv = new WebView(this);
        setContentView(wv);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        wv.setBackgroundColor(0xFF000000);
        wv.addJavascriptInterface(new Bridge(), "Android");
        wv.loadUrl("file:///android_asset/tv.html");
        startServer();
    }

    class Bridge {
        @JavascriptInterface public void setState(String s) { state = s; }
        @JavascriptInterface public void exit() { runOnUiThread(() -> finish()); }
        @JavascriptInterface public String getIp() {
            try {
                for (Enumeration<NetworkInterface> e = NetworkInterface.getNetworkInterfaces(); e.hasMoreElements();) {
                    NetworkInterface n = e.nextElement();
                    for (Enumeration<InetAddress> a = n.getInetAddresses(); a.hasMoreElements();) {
                        InetAddress ia = a.nextElement();
                        if (!ia.isLoopbackAddress() && ia instanceof Inet4Address && ia.isSiteLocalAddress())
                            return ia.getHostAddress();
                    }
                }
            } catch (Exception ignored) {}
            return "TV-IP-not-found";
        }
    }

    void startServer() {
        new Thread(() -> {
            try {
                server = new ServerSocket();
                server.setReuseAddress(true);
                server.bind(new InetSocketAddress(8080));
                while (!server.isClosed()) {
                    final Socket c = server.accept();
                    new Thread(() -> handle(c)).start();
                }
            } catch (Exception ignored) {}
        }).start();
    }

    String line(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int ch;
        while ((ch = in.read()) != -1 && ch != '\n') if (ch != '\r') sb.append((char) ch);
        return sb.toString();
    }

    void handle(Socket c) {
        try {
            c.setSoTimeout(5000);
            InputStream in = new BufferedInputStream(c.getInputStream());
            String req = line(in);
            int len = 0;
            String h;
            while ((h = line(in)).length() > 0)
                if (h.toLowerCase().startsWith("content-length:")) len = Integer.parseInt(h.substring(15).trim());
            len = Math.min(len, 4096);
            byte[] body = new byte[len];
            for (int r = 0; r < len; ) { int n = in.read(body, r, len - r); if (n < 0) break; r += n; }
            String[] p = req.split(" ");
            String path = p.length > 1 ? p[1] : "/";
            String type = "text/plain; charset=utf-8";
            byte[] out;
            if (path.startsWith("/state")) {
                type = "application/json; charset=utf-8";
                out = state.getBytes("UTF-8");
            } else if (path.startsWith("/cmd")) {
                final String js = "onCmd(" + JSONObject.quote(new String(body, "UTF-8")) + ")";
                runOnUiThread(() -> wv.evaluateJavascript(js, null));
                out = "ok".getBytes();
            } else {
                type = "text/html; charset=utf-8";
                InputStream a = getAssets().open("phone.html");
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[4096]; int n;
                while ((n = a.read(buf)) > 0) bo.write(buf, 0, n);
                a.close();
                out = bo.toByteArray();
            }
            OutputStream os = c.getOutputStream();
            os.write(("HTTP/1.1 200 OK\r\nContent-Type: " + type + "\r\nContent-Length: " + out.length +
                    "\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n").getBytes());
            os.write(out);
            os.flush();
        } catch (Exception ignored) {
        } finally {
            try { c.close(); } catch (Exception ignored) {}
        }
    }

    @Override public void onBackPressed() {
        wv.evaluateJavascript("onBack()", v -> { if ("false".equals(v)) finish(); });
    }

    @Override protected void onDestroy() {
        try { if (server != null) server.close(); } catch (Exception ignored) {}
        super.onDestroy();
    }
}
